/* Copyright (c) 2011 The WebM project authors. All Rights Reserved. */
/*  */
/* Use of this source code is governed by a BSD-style license */
/* that can be found in the LICENSE file in the root of the source */
/* tree. An additional intellectual property rights grant can be found */
/* in the file PATENTS.  All contributing project authors may */
/* be found in the AUTHORS file in the root of the source tree. */
static const char* const cfg = "--target=x86_64-linux-gcc --disable-unit-tests --enable-static --disable-shared --disable-vp9 --enable-vp8 --enable-examples --enable-debug --enable-debug-libs --extra-cflags=-fPIC --disable-runtime-cpu-detect";
const char *vpx_codec_build_config(void) {return cfg;}
